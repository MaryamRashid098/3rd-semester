public class MediaNode {
    MediaItem data;
    MediaNode next;

    public MediaNode(MediaItem data) {
        this.data = data;
        next = null;
    }
}
