//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        SlideShow slideShow = new SlideShow();

        MediaItem item1 = new MediaItem("a1","ABC","123",2);
        MediaItem item2 = new MediaItem("a2","EFG","123",2);
        MediaItem item3 = new MediaItem("a3","XYZ","123",2);

        slideShow.addMedia(item1);
        slideShow.addMedia(item2);
        slideShow.addMedia(item3);

        slideShow.showStart();

        slideShow.removeMedia("a1");
        slideShow.getPlaylistOrder();


    }
}