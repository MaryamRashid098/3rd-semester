public class SlideShow {
    MediaNode currentMedia;

    public void addMedia(MediaItem item){
        MediaNode newNode = new MediaNode(item);
        if(currentMedia==null){
            currentMedia =  newNode;
            newNode.next = newNode;
        }
        else{
            MediaNode temp = currentMedia;
            while(temp.next!=currentMedia){
                temp = temp.next;
            }
            temp.next= newNode;
            newNode.next = currentMedia;

        }
    }

    public void removeMedia(String mediaId){
        MediaNode temp = currentMedia;
        MediaNode prev = null;
        do{
            if(temp.data.getMediaID().equals(mediaId)){
                if(prev==null){
                    if(temp.next==null){    //only one item
                        currentMedia=null;
                    }
                    else{          // item is head
                        while(temp.next!=currentMedia){
                            temp=temp.next;
                        }
                       temp.next = currentMedia.next;

                    }
                }
                else{
                    prev.next = temp.next;
                }
            }
            else{
                prev=temp;
                temp= temp.next;
            }

        }while(temp!=currentMedia);
    }

    public MediaItem playNext(){
        if(currentMedia==null){
            System.out.println("No media to display!");
        }
        else{
            currentMedia = currentMedia.next;
            currentMedia.data.play();
            return currentMedia.data;
        }
        return null;
    }

    public void showStart(){
        if(currentMedia==null){
            System.out.println("no media in playlist!");
        }
        else{
            int count=0;
            do{
                currentMedia.data.play();
                currentMedia = currentMedia.next;
                count++;
            }
            while(count>0);

        }
    }

    public void jumpToMedia(String mediaid){
        if(currentMedia==null){
            System.out.println("no availble media");
        }
        else{
            MediaNode temp = currentMedia;
            do{
                if(temp.data.getMediaID().equals(mediaid)){
                    currentMedia = temp;
                }
                else{
                    temp = temp.next;
                }
            }while(temp!=currentMedia);
        }
    }

    public void getPlaylistOrder(){
        if(currentMedia==null){
            System.out.println("no media in playlist!");
        }
        else{
            MediaNode temp = currentMedia;
            do{
                System.out.println(temp.data.getTitle());
            }while(temp!=currentMedia);
        }
    }




}
