public class MediaItem {

    private String mediaID, title, filePath;
    private int duration;

    public MediaItem(String mediaID, String title, String filePath, int duration) {
        this.mediaID = mediaID;
        this.title = title;
        this.filePath = filePath;
        this.duration = duration;
    }

    public String getMediaID() {
        return mediaID;
    }

    public String getTitle() {
        return title;
    }

    public String getFilePath() {
        return filePath;
    }

    public int getDuration() {
        return duration;
    }

    public void play(){
        System.out.println(getTitle()+getDuration()+getMediaID()+getFilePath());
        try{
            Thread.sleep(duration*1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

}
