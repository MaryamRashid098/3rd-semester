import java.util.ArrayList;
import java.util.Stack;

public class RPN {

    public static int precedence(String operator) {
        switch (operator) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            case "^":
                return 3;
        }
        return 0;
    }

    public static boolean rightAssociation(String operator) {
        if (operator.equals("^")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isOperator(String op) {
        switch (op) {
            case "+":
            case "-":
            case "*":
            case "/":
            case "^":
                return true;
        }
        return false;
    }


    public String PostFix(String input) {
        Stack<String> stack = new Stack();
        ArrayList<String> output = new ArrayList<>();

        String[] tokens = input.trim().split(" ");
        for (String token : tokens) {
            if (token.matches("[A-Za-z0-9]+")) {
                output.add(token);
            } else if (isOperator(token)) {
                while (!stack.isEmpty() && !stack.peek().equals("(") &&
                        ((!rightAssociation(token) && precedence(stack.peek()) >= precedence(token))
                        || (rightAssociation(token) && precedence(stack.peek()) > precedence(token)))) {
                    String val = stack.pop();
                    output.add(val);
                }
                stack.push(token);
            }
            else if (token.equals("(")) {
                stack.push(token);
            }
            else if (token.equals(")")) {
                while(!stack.isEmpty() && !stack.peek().equals("(")){
                    output.add(stack.pop());
                }
                if(!stack.isEmpty() && stack.peek().equals("(")){
                    stack.pop();
                }
            }
        }
        while(!stack.isEmpty()){
            output.add(stack.pop());
        }
        return String.join(" ",output);
    }


}

