import java.util.NoSuchElementException;
import java.util.Queue;

// LINEAR QUEUE
public class MyQueue {
    private int[] arr;
    private int rear;
    private int front;

    public MyQueue(){
        arr = new int[5];
        front = rear = -1;
    }

    public void enqueue(int val){
        if(rear == arr.length-1){
            System.out.println("QUEUE FULL");
        }
        else{
            arr[++rear] = val;
        }
    }

    public int dequeue() {
        if(front==-1&&rear==-1){
            throw new NoSuchElementException("QUEUE EMPTY");
        }
        else{
            int v = arr[++front];
            if(front==rear){
                front=rear=-1;
            }
            return v;
        }


    }
}
