public class CircularQueue {
    Runway[] queue;
    int rear;
    int front;

    public CircularQueue() {
        queue = new Runway[10];
        front = rear = -1;
    }

    public void enqueue(Runway runway) {
        if ((front == 0 && rear == queue.length - 1) || (front == (rear + 1) % queue.length)) {
            System.out.println("No runways available!");
        } else {
            rear = (rear + 1) % queue.length;
            queue[rear] = runway;
            if (front == -1) {
                front = 0;
            }
        }
    }

    public Runway dequeue() {
        if (front == -1 && rear == -1) {
            System.out.println("No runways in use.");
            return null;
        } else {
            Runway r = queue[front];
            if (front == rear) {
                front = rear = -1;
            } else {
                front = (front + 1) % queue.length;
            }
            return r;
        }
    }

    public boolean isEmpty() {
        return front == -1;
    }

    public boolean isFull() {
        return (front == 0 && rear == queue.length - 1) || (front == (rear + 1) % queue.length);
    }
}
