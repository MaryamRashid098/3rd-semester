public class Aircraft {
    private String flightNum;
    private int priority; // 1 = emergency, 2 = landing, 3 = takeoff

    public Aircraft(String flightNum, int priority) {
        this.flightNum = flightNum;
        this.priority = priority;
    }

    public String getFlightNum() {
        return flightNum;
    }

    public int getPriority() {
        return priority;
    }
}
