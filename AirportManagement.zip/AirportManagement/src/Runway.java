public class Runway {
    private static int counter = 0;
    private int runwayNum;
    private Aircraft assignedAircraft;

    public Runway() {
        this.runwayNum = ++counter;
        this.assignedAircraft = null;
    }

    public int getRunwayNum() {
        return runwayNum;
    }

    public Aircraft getAssignedAircraft() {
        return assignedAircraft;
    }

    public void setAssignedAircraft(Aircraft a) {
        this.assignedAircraft = a;
    }

    @Override
    public String toString() {
        return "Runway #" + runwayNum;
    }
}
