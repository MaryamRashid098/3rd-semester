public class AirportSystem {
    public PriorityQueue aircraftQueue;
    public CircularQueue runwayQueue;
    public CircularQueue occupiedRunways; // like occupied beds

    public AirportSystem() {
        aircraftQueue = new PriorityQueue();
        runwayQueue = new CircularQueue();
        occupiedRunways = new CircularQueue();

        // initialize runways
        for (int i = 0; i < 5; i++) {
            runwayQueue.enqueue(new Runway());
        }
    }

    // add aircraft into priority queue
    public void requestRunway(Aircraft a) {
        aircraftQueue.enqueue(a);
        System.out.println("Aircraft " + a.getFlightNum() + " requested runway (priority: " + a.getPriority() + ")");
    }

    // assign runway to aircraft based on priority
    public void assignRunway() {
        if (aircraftQueue.isEmpty()) {
            System.out.println("No aircraft waiting.");
            return;
        }
        if (runwayQueue.isEmpty()) {
            System.out.println("No runways available. Aircraft must hold.");
            return;
        }

        Aircraft a = aircraftQueue.dequeue(); // highest priority first
        Runway r = runwayQueue.dequeue();     // get available runway
        r.setAssignedAircraft(a);
        occupiedRunways.enqueue(r);

        System.out.println("Assigned " + a.getFlightNum() + " (priority " + a.getPriority() + ") to " + r);
    }

    // free up a runway after aircraft departs/lands
    public void releaseRunway(String flightNum) {
        for (int i = 0; i < occupiedRunways.queue.length; i++) {
            Runway r = occupiedRunways.queue[i];
            if (r != null && r.getAssignedAircraft() != null) {
                if (r.getAssignedAircraft().getFlightNum().equals(flightNum)) {
                    System.out.println("Aircraft " + flightNum + " cleared. " + r + " is now free.");
                    r.setAssignedAircraft(null);
                    runwayQueue.enqueue(r);
                    occupiedRunways.queue[i] = null;
                    break;
                }
            }
        }
    }
}

// Main.java
public class Main {
    public static void main(String[] args) {
        AirportSystem airport = new AirportSystem();

        airport.requestRunway(new Aircraft("PK123", 2)); // landing
        airport.requestRunway(new Aircraft("EK404", 3)); // takeoff
        airport.requestRunway(new Aircraft("QF911", 1)); // emergency

        airport.assignRunway();
        airport.assignRunway();
        airport.assignRunway();

        airport.releaseRunway("QF911"); // emergency cleared
        airport.assignRunway(); // see if waiting aircraft can now use freed runway
    }
}
