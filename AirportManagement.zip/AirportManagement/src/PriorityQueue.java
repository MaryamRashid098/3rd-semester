public class PriorityQueue {



        Aircraft[] queue;
        int rear;
        int front;
        int size;

        public PriorityQueue() {
            queue = new Aircraft[10];
            size = queue.length;
            rear = -1;
            front = 0;
        }

        public void enqueue(Aircraft aircraft) {
            if (rear == size - 1) {
                System.out.println("Queue Full");
            } else if (rear == -1) {
                queue[++rear] = aircraft;
            } else {
                rear++;
                insert(aircraft);
            }
        }

        public Aircraft dequeue() {
            if (isEmpty()) {
                return null;
            }
            return queue[front++];
        }

        public boolean isEmpty() {
            return rear < front;
        }

        private void insert(Aircraft aircraft) {
            int i = 0;
            while (i < rear && aircraft.getPriority() >= queue[i].getPriority()) {
                i++;
            }

            for (int j = rear; j > i; j--) {
                queue[j] = queue[j - 1];
            }
            queue[i] = aircraft;
        }
}
