//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Demo {
    public static void main(String[] args) {
        AirportSystem airport = new AirportSystem();

        airport.requestRunway(new Aircraft("PK123", 2)); // landing
        airport.requestRunway(new Aircraft("EK404", 3)); // takeoff
        airport.requestRunway(new Aircraft("QF911", 1)); // emergency

        airport.assignRunway();
        airport.assignRunway();
        airport.assignRunway();

        airport.releaseRunway("QF911");
        airport.assignRunway();
    }
}