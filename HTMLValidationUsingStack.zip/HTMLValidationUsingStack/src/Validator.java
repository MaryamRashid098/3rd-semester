public class Validator {
    public static boolean validate(String string){
        Stack stack = new Stack(50);
        int i=0;

        while (i<string.length()){

            if(string.charAt(i)=='<'){
                int j = string.indexOf('>',i);
                  if(j==-1) { return false; } // invalid suntax of html

                String tag = string.substring(i+1,j);    //content of tag between <>
                    if (tag.endsWith("/")) { i=j+1; continue;}  // ignore smth like <br/>


                // check if it is clsoing or opening
                if(tag.startsWith("/")){
                    String tagg = tag.substring(1);

                    if(!stack.isEmpty()&&stack.peek().equals(tagg)){
                        stack.pop();
                    }
                    else{
                        return false;
                    }
                }
                else{
                    stack.push(tag);
                }
                i = j+1; // move ahead to the next tag

            }
            else{
                i++;  // goes ahead through non-tag part
            }
        }
        return stack.isEmpty();  //even if tags match, stack needs to be empty.

    }
}