import java.util.Scanner;

public class HTMLValidator {
    Node head;

    public void addNode(String string, String validity){
        Node newNode = new Node(string, validity);
        if(head==null){
            head=newNode;
        }
        else{
            Node temp=head;
            while(temp.next!=null){
                temp=temp.next;
            }
            temp.next=newNode;
        }

        }
        public void displayList(){
            Node temp=head;
            while(temp!=null){
                System.out.println("HTML STRING: "+temp.html);
                System.out.println("Validity: "+temp.validity);
                temp=temp.next;
            }

        }

    public static void main(String[] args) {
        HTMLValidator history = new HTMLValidator();

        String input = "<html><body><h1>Hello</h1></body></html>";
        boolean isValid = Validator.validate(input);
        String validity;
        if(isValid){
            validity = "Valid";
        }
        else{
            validity = "Invalid";
        }

        history.addNode(input, validity);
        history.displayList();




    }
    }

