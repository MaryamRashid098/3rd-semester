
import java.util.EmptyStackException;

class Stack {
    private String[] arr;
    private int tos;

    public Stack(int size) {
        arr = new String[size];
        tos = -1;
    }

    public void push(String val) {
        if (tos == arr.length - 1) {
            // expand capacity
            String[] temp = new String[arr.length * 2];
            for (int i = 0; i < arr.length; i++) {
                temp[i] = arr[i];
            }
            arr = temp;
        }
        arr[++tos] = val;
    }

    public String pop() {
        if (isEmpty()) throw new EmptyStackException();
        return arr[tos--];
    }

    public String peek() {
        if (isEmpty()) throw new EmptyStackException();
        return arr[tos];
    }

    public boolean isEmpty() {
        return tos == -1;
    }
}





