public class Node {
    String html;
    String validity;
    Node next;

    public Node(String html, String validity) {
        this.html = html;
        this.validity=validity;
        this.next = null;
    }
}
