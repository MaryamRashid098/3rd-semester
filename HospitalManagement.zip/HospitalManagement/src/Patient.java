public class Patient {
    private int state;
    private String name;

    public Patient(String name, int state){
        this.name = name;
        this.state = state;
    }

    public int getState(){
        return state;
    }
    public void setState(int state){
        this.state=state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
