public class Bed {
    private int bedNum=0;
    private static int count=0;
    private Patient patient;

    public Bed(){
        bedNum = ++count;
        patient = null;
    }

    public void setBedNum(int bedNum) {
        this.bedNum = bedNum;
    }

    public int getBedNum() {
        return bedNum;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Patient getPatient() {
        return patient;
    }
}
