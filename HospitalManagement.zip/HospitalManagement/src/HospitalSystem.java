public class HospitalSystem {
    public PriorityQueue patientList;
    public CircularQueue bedList;
    public CircularQueue occupiedBedList;

    public HospitalSystem(){
        patientList = new PriorityQueue();
        bedList = new CircularQueue();
        occupiedBedList = new CircularQueue();
        for(int i=0; i<10; i++){
            bedList.enqueue(new Bed());
        }
    }

    public void addPatient(Patient patient){
        patientList.enqueue(patient);
        System.out.println("Patient added to patient list.");
    }

    public void assignBed(){
        Patient p  = patientList.dequeue();
        Bed b = bedList.dequeue();
        b.setPatient(p);
        occupiedBedList.enqueue(b);
        System.out.println("Assigned "+ p.getName() + "with priority: " + p.getState() + "to Bed "+ b.getBedNum());
    }

    public void dischargePatient(Patient p){
        for(int i=0;i<occupiedBedList.queue.length;i++){
            Bed b = occupiedBedList.dequeue();
            if(b.getPatient().getName().equals(p.getName()) && b.getPatient().getState()==(p.getState())){
                b.setPatient(null);
                bedList.enqueue(b);
                System.out.println("Patient: "+p.getName()+", state: "+p.getState()+" discharged.");
            }
            else{
                occupiedBedList.enqueue(b);
            }
        }
    }





















}
