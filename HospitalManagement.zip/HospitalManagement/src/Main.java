//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        HospitalSystem hospital = new HospitalSystem();

        Patient p1 = new Patient("m",2);
        Patient p2 = new Patient("c",3);
        Patient p3 = new Patient("i",1);

        hospital.addPatient(p1);
        hospital.addPatient(p2);
        hospital.addPatient(p3);

        hospital.assignBed();
        hospital.assignBed();
        hospital.assignBed();

        hospital.dischargePatient(p3);




    }
}