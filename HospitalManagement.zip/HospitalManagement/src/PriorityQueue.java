public class PriorityQueue {
    Patient queue[];
    int rear;
    int front;

    public PriorityQueue(){
        queue = new Patient[10];
        rear =-1;
        front=0;
    }

    public void enqueue(Patient patient){
        if(rear== queue.length-1){
            System.out.println("List Full");
        }
        else if(rear==-1){
            queue[++rear] = patient;
        }
        else{
             rear++;
             insert(patient);

        }
    }

    public Patient dequeue(){
       if(front>rear){
           System.out.println("Queue empty");
           return null;
       }
        return queue[front++];
    }

    public void insert(Patient patient){
        int i=0;
        while(i<rear && patient.getState()>=queue[i].getState()){
            i++;
        }

        for(int j=rear;j>i;j--){
            queue[j] = queue[j-1];
        }
        queue[i]=patient;
    }


}
