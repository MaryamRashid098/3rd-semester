public class CircularQueue {
    Bed queue[];
    int rear;
    int front;

    public CircularQueue(){
        queue = new Bed[10];
        front = rear = -1;
    }

    public void enqueue(Bed bed){
        if((front==0 && rear== queue.length) || (front==(rear+1)% queue.length)){
            System.out.println("No beds available!");
        }
        else{
            rear = (rear+1)% queue.length;
            queue[rear] = bed;
            if(front==-1){
                front=0;
            }
        }
    }

    public Bed dequeue(){
        if(front==-1 && rear==-1){
            System.out.println("No patients admitted");
            return null;
        }
        else{
            Bed bed = queue[front];
            if(front==rear){
                front=rear=-1;
            }
            else{
                front = (front+1)% queue.length;
            }
           return bed;
        }
    }



























}
