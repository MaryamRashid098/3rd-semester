
    import java.util.EmptyStackException;

    // ==========================
// Stack Implementation
// ==========================
    class Stack {
        private int[] arr;
        private int tos;

        public Stack(int size) {
            arr = new int[size];
            tos = -1;
        }

        public void push(int val) {
            if (tos == arr.length - 1) {
                // expand capacity
                int[] temp = new int[arr.length * 2];
                for (int i = 0; i < arr.length; i++) {
                    temp[i] = arr[i];
                }
                arr = temp;
            }
            arr[++tos] = val;
        }

        public int pop() {
            if (isEmpty()) throw new EmptyStackException();
            return arr[tos--];
        }

        public int peek() {
            if (isEmpty()) throw new EmptyStackException();
            return arr[tos];
        }

        public boolean isEmpty() {
            return tos == -1;
        }
    }





