
    class RPN {
        private Stack stack;
        private String expression;

        public RPN(String expr) {
            this.expression = expr;
            this.stack = new Stack(10); // initial stack size
        }

        // 🔹 Tokenizer function (private, only used inside RPN)
        private String[] tokenize() {
            return expression.split(" ");
        }

        // 🔹 Evaluate function
        public int evaluate() {
            String[] tokens = tokenize(); // get tokens here
            for (int i=0;i< tokens.length;i++) {
                if (isOperator(tokens[i])) {
                    int b = stack.pop();
                    int a = stack.pop();
                    int result = applyOperator(tokens[i], a, b);
                    stack.push(result);
                } else {
                    int num = Integer.parseInt(tokens[i]);
                    stack.push(num);
                }
            }
            return stack.pop();
        }

        private boolean isOperator(String token) {
            return token.equals("+") || token.equals("-") ||
                    token.equals("*") || token.equals("/");
        }

        private int applyOperator(String op, int a, int b) {
            switch (op) {
                case "+": return a + b;
                case "-": return a - b;
                case "*": return a * b;
                case "/": return a / b;
            }
            throw new IllegalArgumentException("Invalid operator: " + op);
        }

        public static void main(String[] args) {
            String expr = "3 4 + 2 *";

            RPN rpn = new RPN(expr);
            int result = rpn.evaluate();

            System.out.println("Expression: " + expr);
            System.out.println("Result: " + result);
        }
    }






