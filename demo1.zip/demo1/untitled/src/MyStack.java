public class MyStack {

    private int[] arr;
    int tos;

    public MyStack(int size) {
        arr = new int[size];
        tos = -1;

    }

    void push(int val){
            if(tos==arr.length-1) {
                int[] temp = new int[arr.length*2];
                for(int i=0;i<arr.length;i++){
                    temp[i]=arr[i];
                }
                arr = temp;
                arr[++tos] = val;
            }
        arr[++tos] = val;
    }

    int pop(){
        if(tos==-1) {
            System.out.println("Stack Empty!");
            return 0;
        }
        System.out.println(arr[tos]);
        tos--;
        return 0;
    }

}
