import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;
import java.util.StringTokenizer;


public class Rpn {

    private Stack<Integer> stack;
    private String input;

    public Rpn(String input){
        this.input = input;
        stack = new Stack<>();

    }

    public boolean checkOperator(String input){
        if(input.equals("+") || input.equals("-") ||
                input.equals("*") || input.equals("/")){
            return true;
        }
        return false;
    }

    public int Operate(int token1, int token2, String operator){
        switch (operator){
            case("+"):
                return token1+token2;
            case("-"):
                return token1-token2;
            case("*"):
                return token1*token2;
            case("/"):
                return token1/token2;
        }
        throw new IllegalArgumentException("Invalid operator: " + operator);
    }

    private String[] tokenize(){
        String[] tokens = input.split(" ");
        return tokens;
    }

    public int Evaluate(){
        int a,b,result = 0;
        String[] tokens = tokenize();
        for(int i=0;i<tokens.length;i++){
            if (checkOperator(tokens[i])){
                b = stack.pop();
                a =stack.pop();
                result = Operate(a,b,tokens[i]);
                stack.push(result);
            }
            else{
                stack.push(Integer.parseInt(tokens[i]));
            }
        }
        return result;
    }

}
