import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Demo {

    public void endValue(String val, ArrayList<String> list){
        list.add(val);
    }
    public void startValue(String val, ArrayList<String> list){
        list.add(0,val);
    }

    public void afterValue(String val, String item, ArrayList<String> list) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).equals(item)){
                list.add(i + 1, val);
                return;}
        }
    }

    public void beforeValue(String val, String item, ArrayList<String> list){
        for(int i=0; i<list.size(); i++){
            if(list.get(i).equals(item)){
                list.add(i, val);
                return;}
        }
    }

    public void display(ArrayList<String> list){
        System.out.println("Array List:\n"+list);
    }

    public void deleteLastval(ArrayList<String> list){
        list.remove(list.size()-1);
    }
    public void deleteFirstval(ArrayList<String> list){
        list.remove(0);
    }
    public void deleteVal(ArrayList<String> list, String val){
        for(int i=0; i<list.size();i++){
            if(list.get(i).equals(val))
                list.remove(i);
        }
    }


    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>(Arrays.asList("maths","english","biology"));
        Demo obj = new Demo();
        obj.display(list);

    while(true) {
        System.out.println("CHOOSE FUNCTION:");
        System.out.println("1. Insert the value at end of the list\n" +
                "2. Insert the value at start of the list\n" +
                "3. Insert the value after specific value\n" +
                "4. Insert the value before specific value\n" +
                "5. Display the array list\n" +
                "6. Delete the value from end of the list\n" +
                "7. Delete the value from start of the list\n" +
                " 8. Delete specific value.\n" +
                "9. EXIT\n");

        Scanner sc = new Scanner(System.in);
        int choice = Integer.parseInt(sc.nextLine());

        Scanner s = new Scanner(System.in);
        String val = "";
        String item = "";
        int index = 0;

        switch (choice) {
            case 1:
                System.out.println("Enter value: ");
                val = s.nextLine();
                obj.endValue(val, list);
                obj.display(list);
                break;
            case 2:
                System.out.println("Enter Value: ");
                val = s.nextLine();
                obj.startValue(val, list);
                obj.display(list);
                break;
            case 3:
                System.out.println("Enter value to add: ");
                val = s.nextLine();
                System.out.println("What value do you want to follow:");
                item = s.nextLine();
                obj.afterValue(val, item, list);
                obj.display(list);
                break;
            case 4:
                System.out.println("Enter value to add: ");
                val = s.nextLine();
                System.out.println("Which value do you want to insert the new item before?: ");
                item = s.nextLine();
                obj.beforeValue(val, item, list);
                obj.display(list);
                break;
            case 5:
                obj.display(list);
                break;
            case 6:
                obj.deleteLastval(list);
                obj.display(list);
                break;
            case 7:
                obj.deleteFirstval(list);
                obj.display(list);
                break;
            case 8:
                System.out.println("Enter value to delete: ");
                val = s.nextLine();
                obj.deleteVal(list, val);
                obj.display(list);
                break;
            case 9:
                return;
            default:
                System.out.println("Invalid choice. Try again!");


        }
    }
    }
}
